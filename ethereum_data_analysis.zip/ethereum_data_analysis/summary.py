import pandas as pd

df = pd.read_csv("transactions.csv")

total_tx = len(df)
total_value = df['value_ether'].sum()
unique_senders = df['from'].nunique()
unique_receivers = df['to'].nunique()

summary = {
    "Total Transactions": total_tx,
    "Total Value (Ether)": total_value,
    "Unique Senders": unique_senders,
    "Unique Receivers": unique_receivers
}

with open("summary.txt", "w") as f:
    for k, v in summary.items():
        f.write(f"{k}: {v}\n")
