import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("transactions.csv")

high_value = df[df['value_ether'] > 10]
high_value.to_csv("high_value_transactions.csv", index=False)

plt.plot(df['block'], df['gas_price'])
plt.xlabel("Block")
plt.ylabel("Gas Price (Gwei)")
plt.title("Gas Price Trend")
plt.savefig("gas_price_trend.png")
