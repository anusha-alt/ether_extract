from web3 import Web3
from config import INFURA_URL
import pandas as pd

web3 = Web3(Web3.HTTPProvider(INFURA_URL))
latest = web3.eth.block_number
data = []

for i in range(latest - 10, latest):
    block = web3.eth.get_block(i, full_transactions=True)
    for tx in block.transactions:
        data.append({
            "hash": tx.hash.hex(),
            "from": tx['from'],
            "to": tx['to'],
            "value_ether": web3.from_wei(tx.value, 'ether'),
            "gas": tx.gas,
            "gas_price": web3.from_wei(tx.gasPrice, 'gwei'),
            "block": i
        })

df = pd.DataFrame(data)
df.to_csv("transactions.csv", index=False)
