# Ethereum Blockchain Data Analysis

This project extracts and analyzes transaction data from the Ethereum blockchain using Web3.py and Infura. It includes functionality to detect high-value transfers and visualize gas usage over time.
