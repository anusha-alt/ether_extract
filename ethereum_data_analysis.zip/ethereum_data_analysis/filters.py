import pandas as pd

def filter_by_address(df, address):
    return df[(df['from'] == address) | (df['to'] == address)]

def filter_by_min_value(df, min_value_eth):
    return df[df['value_ether'] >= min_value_eth]
