import pandas as pd
from filters import filter_by_address, filter_by_min_value

df = pd.read_csv("transactions.csv")

address = input("Enter address to filter (or leave blank): ")
min_value = input("Enter minimum value in ETH (or leave blank): ")

if address:
    df = filter_by_address(df, address)

if min_value:
    try:
        min_value = float(min_value)
        df = filter_by_min_value(df, min_value)
    except ValueError:
        print("Invalid minimum value entered.")

df.to_csv("filtered_transactions.csv", index=False)
print("Filtered transactions saved to filtered_transactions.csv")
